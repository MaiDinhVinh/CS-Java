A Pen created at CodePen.io. You can find this one at https://codepen.io/andy31415/pen/FtKzs.

 Just playing around with dialog design in bootstrap.
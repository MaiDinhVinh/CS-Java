CREATE VIEW TABLES_EXTENSIONS AS
SELECT `cat`.`name`                       AS `TABLE_CATALOG`,
       `sch`.`name`                       AS `TABLE_SCHEMA`,
       `tbl`.`name`                       AS `TABLE_NAME`,
       `tbl`.`engine_attribute`           AS `ENGINE_ATTRIBUTE`,
       `tbl`.`secondary_engine_attribute` AS `SECONDARY_ENGINE_ATTRIBUTE`
FROM ((`mysql`.`tables` `tbl` JOIN `mysql`.`schemata` `sch`
       ON ((`tbl`.`schema_id` = `sch`.`id`))) JOIN `mysql`.`catalogs` `cat` ON ((`cat`.`id` = `sch`.`catalog_id`)))
WHERE ((0 <> can_access_table(`sch`.`name`, `tbl`.`name`)) AND (0 <> is_visible_dd_object(`tbl`.`hidden`)));


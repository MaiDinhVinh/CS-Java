CREATE VIEW INNODB_FOREIGN_COLS AS
SELECT (CONCAT(`sch`.`name`, '/', `fk`.`name`) COLLATE utf8mb3_tolower_ci) AS `ID`,
       `col`.`name`                                                        AS `FOR_COL_NAME`,
       `fk_col`.`referenced_column_name`                                   AS `REF_COL_NAME`,
       `fk_col`.`ordinal_position`                                         AS `POS`
FROM ((((`mysql`.`foreign_key_column_usage` `fk_col` JOIN `mysql`.`foreign_keys` `fk`
         ON ((`fk`.`id` = `fk_col`.`foreign_key_id`))) JOIN `mysql`.`tables` `tbl`
        ON ((`fk`.`table_id` = `tbl`.`id`))) JOIN `mysql`.`schemata` `sch`
       ON ((`fk`.`schema_id` = `sch`.`id`))) JOIN `mysql`.`columns` `col`
      ON (((`tbl`.`id` = `col`.`table_id`) AND (`fk_col`.`column_id` = `col`.`id`))))
WHERE ((`tbl`.`type` <> 'VIEW') AND (`tbl`.`hidden` = 'Visible') AND (`tbl`.`se_private_id` IS NOT NULL) AND
       (`tbl`.`engine` = 'INNODB'));


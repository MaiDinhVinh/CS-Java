CREATE VIEW CHECK_CONSTRAINTS AS
SELECT (`cat`.`name` COLLATE utf8mb3_tolower_ci) AS `CONSTRAINT_CATALOG`,
       (`sch`.`name` COLLATE utf8mb3_tolower_ci) AS `CONSTRAINT_SCHEMA`,
       `cc`.`name`                               AS `CONSTRAINT_NAME`,
       `cc`.`check_clause_utf8`                  AS `CHECK_CLAUSE`
FROM (((`mysql`.`check_constraints` `cc` JOIN `mysql`.`tables` `tbl`
        ON ((`cc`.`table_id` = `tbl`.`id`))) JOIN `mysql`.`schemata` `sch`
       ON ((`tbl`.`schema_id` = `sch`.`id`))) JOIN `mysql`.`catalogs` `cat` ON ((`cat`.`id` = `sch`.`catalog_id`)))
WHERE ((0 <> can_access_table(`sch`.`name`, `tbl`.`name`)) AND (0 <> is_visible_dd_object(`tbl`.`hidden`)));


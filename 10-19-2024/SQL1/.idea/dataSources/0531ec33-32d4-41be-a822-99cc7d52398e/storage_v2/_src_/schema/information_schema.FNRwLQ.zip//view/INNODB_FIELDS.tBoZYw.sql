CREATE VIEW INNODB_FIELDS AS
SELECT get_dd_index_private_data(`idx`.`se_private_data`, 'id') AS `INDEX_ID`,
       `col`.`name`                                             AS `NAME`,
       (`fld`.`ordinal_position` - 1)                           AS `POS`
FROM (((`mysql`.`index_column_usage` `fld` JOIN `mysql`.`columns` `col`
        ON ((`fld`.`column_id` = `col`.`id`))) JOIN `mysql`.`indexes` `idx`
       ON ((`fld`.`index_id` = `idx`.`id`))) JOIN `mysql`.`tables` `tbl` ON ((`tbl`.`id` = `idx`.`table_id`)))
WHERE ((`tbl`.`type` <> 'VIEW') AND (`tbl`.`hidden` = 'Visible') AND (0 = `fld`.`hidden`) AND
       (`tbl`.`se_private_id` IS NOT NULL) AND (`tbl`.`engine` = 'INNODB'));


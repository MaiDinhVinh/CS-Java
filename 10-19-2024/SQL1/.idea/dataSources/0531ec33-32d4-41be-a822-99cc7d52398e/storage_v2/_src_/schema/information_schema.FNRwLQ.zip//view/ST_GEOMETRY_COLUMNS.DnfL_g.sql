CREATE VIEW ST_GEOMETRY_COLUMNS AS
SELECT `information_schema`.`cols`.`TABLE_CATALOG` AS `TABLE_CATALOG`,
       `information_schema`.`cols`.`TABLE_SCHEMA`  AS `TABLE_SCHEMA`,
       `information_schema`.`cols`.`TABLE_NAME`    AS `TABLE_NAME`,
       `information_schema`.`cols`.`COLUMN_NAME`   AS `COLUMN_NAME`,
       `information_schema`.`srs`.`SRS_NAME`       AS `SRS_NAME`,
       `information_schema`.`cols`.`SRS_ID`        AS `SRS_ID`,
       `information_schema`.`cols`.`DATA_TYPE`     AS `GEOMETRY_TYPE_NAME`
FROM (`information_schema`.`COLUMNS` `cols` LEFT JOIN `information_schema`.`ST_SPATIAL_REFERENCE_SYSTEMS` `srs`
      ON ((`information_schema`.`cols`.`SRS_ID` = `information_schema`.`srs`.`SRS_ID`)))
WHERE (`information_schema`.`cols`.`DATA_TYPE` IN
       ('geometry', 'point', 'linestring', 'polygon', 'multipoint', 'multilinestring', 'multipolygon',
        'geomcollection'));


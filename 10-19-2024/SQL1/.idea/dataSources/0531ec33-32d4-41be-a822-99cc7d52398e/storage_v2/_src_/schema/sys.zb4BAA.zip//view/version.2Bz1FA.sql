CREATE DEFINER = `mysql.sys`@localhost VIEW version AS
SELECT '2.1.3' AS `sys_version`, VERSION() AS `mysql_version`;


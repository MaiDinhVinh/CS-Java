CREATE VIEW VIEW_ROUTINE_USAGE AS
SELECT (`cat`.`name` COLLATE utf8mb3_tolower_ci)            AS `TABLE_CATALOG`,
       (`sch`.`name` COLLATE utf8mb3_tolower_ci)            AS `TABLE_SCHEMA`,
       (`vw`.`name` COLLATE utf8mb3_tolower_ci)             AS `TABLE_NAME`,
       (`vru`.`routine_catalog` COLLATE utf8mb3_tolower_ci) AS `SPECIFIC_CATALOG`,
       (`vru`.`routine_schema` COLLATE utf8mb3_tolower_ci)  AS `SPECIFIC_SCHEMA`,
       `vru`.`routine_name`                                 AS `SPECIFIC_NAME`
FROM ((((`mysql`.`tables` `vw` JOIN `mysql`.`schemata` `sch`
         ON ((`vw`.`schema_id` = `sch`.`id`))) JOIN `mysql`.`catalogs` `cat`
        ON ((`cat`.`id` = `sch`.`catalog_id`))) JOIN `mysql`.`view_routine_usage` `vru`
       ON ((`vru`.`view_id` = `vw`.`id`))) JOIN `mysql`.`routines` `rtn`
      ON (((`vru`.`routine_catalog` = `cat`.`name`) AND (`vru`.`routine_schema` = `sch`.`name`) AND
           (`vru`.`routine_name` = `rtn`.`name`))))
WHERE ((`vw`.`type` = 'VIEW') AND
       (0 <> can_access_routine(`vru`.`routine_schema`, `vru`.`routine_name`, `rtn`.`type`, `rtn`.`definer`, FALSE)) AND
       (0 <> can_access_view(`sch`.`name`, `vw`.`name`, `vw`.`view_definer`, `vw`.`options`)));


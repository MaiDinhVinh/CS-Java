CREATE VIEW TABLESPACES_EXTENSIONS AS
SELECT `tsps`.`name` AS `TABLESPACE_NAME`, `tsps`.`engine_attribute` AS `ENGINE_ATTRIBUTE`
FROM `mysql`.`tablespaces` `tsps`;


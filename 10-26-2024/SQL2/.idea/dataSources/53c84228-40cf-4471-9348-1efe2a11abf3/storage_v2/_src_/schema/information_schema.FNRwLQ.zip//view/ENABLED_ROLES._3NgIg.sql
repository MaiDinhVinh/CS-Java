CREATE VIEW ENABLED_ROLES AS
SELECT `current_user_enabled_roles`.`ROLE_NAME`                                              AS `ROLE_NAME`,
       `current_user_enabled_roles`.`ROLE_HOST`                                              AS `ROLE_HOST`,
       (SELECT IF(COUNT(0), 'YES', 'NO')
        FROM `mysql`.`default_roles`
        WHERE ((`mysql`.`default_roles`.`DEFAULT_ROLE_USER` = `current_user_enabled_roles`.`ROLE_NAME`) AND
               (CONVERT(`mysql`.`default_roles`.`DEFAULT_ROLE_HOST` USING utf8mb4) =
                `current_user_enabled_roles`.`ROLE_HOST`) AND
               (`mysql`.`default_roles`.`USER` = internal_get_username()) AND
               (CONVERT(`mysql`.`default_roles`.`HOST` USING utf8mb4) =
                CONVERT(internal_get_hostname() USING utf8mb4))))                            AS `IS_DEFAULT`,
       IF(internal_is_mandatory_role(`current_user_enabled_roles`.`ROLE_NAME`,
                                     `current_user_enabled_roles`.`ROLE_HOST`), 'YES', 'NO') AS `IS_MANDATORY`
FROM JSON_TABLE(internal_get_enabled_role_json(), '$[*]'
                COLUMNS (`ROLE_NAME` varchar(255) CHARACTER SET utf8mb4 PATH '$.ROLE_NAME', `ROLE_HOST` varchar(255) CHARACTER SET utf8mb4 PATH '$.ROLE_HOST')) `current_user_enabled_roles`;

